-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2022 at 04:37 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajax_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `passkey` varchar(255) NOT NULL,
  `registration_date` datetime DEFAULT current_timestamp(),
  `last_signin` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`id`, `full_name`, `email`, `mobile_no`, `passkey`, `registration_date`, `last_signin`) VALUES
(1, 'Md Farzan', 'mdfarzan@gmail.com', '7845126985', '784514526', '2022-07-12 19:34:33', NULL),
(2, 'Md Farzan', 'mdfarzan772@gmail.com', '7845129635', '607f63a8b6fe22dcfb03fc021b1e90a3', '2022-07-12 19:58:52', NULL),
(3, 'Md Farzan', 'mdfardzan@gmail.com', '7845129658', '607f63a8b6fe22dcfb03fc021b1e90a3', '2022-07-12 20:01:10', NULL),
(4, 'Md Farzan', 'mdfarzan90@jmail.com', '7845126985', '607f63a8b6fe22dcfb03fc021b1e90a3', '2022-07-12 20:01:54', NULL),
(5, 'Md Farzan', 'mdfarzan343@gmai.com', '7845126985', '607f63a8b6fe22dcfb03fc021b1e90a3', '2022-07-12 20:03:39', NULL),
(6, 'Sameer Khan', 'sameerkhan@gmail.com', '7845126985', '607f63a8b6fe22dcfb03fc021b1e90a3', '2022-07-12 20:04:55', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_registration`
--
ALTER TABLE `user_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
